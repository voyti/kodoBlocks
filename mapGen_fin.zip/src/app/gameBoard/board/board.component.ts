import { Component, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import * as Phaser from 'phaser';
import { BackgroundGeneratorService } from '../services/background-generator.service';
type AreaDimensions = (number)[];

@Component({
  selector: 'app-board',
  templateUrl: './board.component.html',
  styleUrls: ['./board.component.scss']
})
export class BoardComponent implements OnInit {
  config: Phaser.Types.Core.GameConfig;
  logger: Console;
  inputWidth: number;
  inputHeight: number;
  inputTileSize: number;
  inputNoiseRes: number;
  additionalConfig: { tileSize: number; noiseRes: number; } | undefined;
  game: Phaser.Game | undefined;

  constructor(private backgroundGeneratorService: BackgroundGeneratorService) {
    this.config = {
      width: 1280,
      height: 720,
      type: Phaser.WEBGL,
      parent: 'board',
      scene: {
        // preload: preload,
          create: this.getPhaserCreate(),
      }
    };

    this.logger = console;
    this.inputWidth = 1280;
    this.inputHeight = 720;
    this.inputTileSize = 20;
    this.inputNoiseRes = 20;
  }

  rerunBoard() {
    this.game?.destroy(true);
    this.config.width = Number(this.inputWidth);
    this.config.height = Number(this.inputHeight);
    this.additionalConfig = { tileSize: this.inputTileSize, noiseRes: this.inputNoiseRes };

    this.initializePhaser();
  }



  ngOnInit(): void {
    this.initializePhaser();
  }

  initializePhaser() {
    this.game = new Phaser.Game(this.config);
  }


  getPhaserCreate(): Phaser.Types.Scenes.SceneCreateCallback {
    const self = this;

    const phaseCreateFunction = (phaserScene: Phaser.Scene) => {
      var graphics = phaserScene.add.graphics();

      if (typeof this.config.height === 'number' && typeof this.config.width === 'number') {
        const areaDimensions: AreaDimensions = [this.config.width, this.config.height];
        this.backgroundGeneratorService.generate(areaDimensions, graphics, phaserScene, this.additionalConfig);
      } else {
        this.logger.warn('Parameter for config.height/config.width are not numbers, can\'t proceed with bg generation');
      }
    };

    return function create (this) {
      phaseCreateFunction(this);

      // graphics.fillStyle(0xffff00, 1);
      // graphics.fillRect(100, 100, 256, 256);

      // graphics.fillStyle(0xff00ff, 0.5);
      // graphics.fillRect(300, 200, 256, 256);

      // graphics.fillStyle(0x00ff00, 1);
      // graphics.fillTriangle(200, 200, 400, 50, 500, 300);
    }
  }

}
