import { Injectable } from '@angular/core';
import noise from 'noisejs';
import _ from 'lodash';

type AreaDimensions = (number)[];
type Tiles = {
   tileX: number;
   tileY: number;
   pointX: number;
   pointY: number;
   value: number;
   category: 'baseline' | 'foreground A' | 'foreground B';
 }[][];

 type AdditionalConfig = { tileSize: number; noiseRes: number; } | undefined;

const MAX_PERLIN_VALUE = 256;

const COLOR_GRASS = 0x91c483;
const COLOR_GROUND = 0xCFB784;
const COLOR_FOREST = 0x125C13;
const COLOR_WATER = 0x38A3A5;
const COLOR_ROCK = 0x99A799;

const TILE_SIZE = 20;
const TILE_POLYGON_SIZE = TILE_SIZE * 4/5;
const TILE_POLYGON_POINTS = 12;

const NOISE_RESOLUTION = 20; // influences how featureless the terrain is; 100 is more homogenous, less is more diverse

@Injectable({
  providedIn: 'root'
})
export class BackgroundGeneratorService {
  noise: any;
  logger: Console;

  constructor() {
    this.noise = new (noise as any).Noise(Math.random());
    this.logger = console;
  }

  generate(areaDimensions: AreaDimensions, graphics: Phaser.GameObjects.Graphics, scene: Phaser.Scene, additionalConfig?: AdditionalConfig) {
    if (areaDimensions?.[0] && areaDimensions?.[1]) {
      const tileSize = additionalConfig?.tileSize || TILE_SIZE;


      const testAreaTileability = (width: number, height: number) => width % tileSize === 0 &&  height % tileSize === 0;
      if (testAreaTileability(areaDimensions[0], areaDimensions[1]) && !this.checkForOperationOverload(tileSize, areaDimensions)) {
        let tiledPoints = this.generateTilesFromArea(this.noise, areaDimensions, tileSize, additionalConfig?.noiseRes);

        this.testPoints(tiledPoints, graphics);
      } else {
        this.logger.warn('Area size ', areaDimensions, ' can\'t be tiled into parts of ', tileSize, ' properly. Aborting');
      }
    }
  }

  private checkForOperationOverload(tileSize: number, areaDimensions: AreaDimensions) {
    const OVERLOAD_VALUE = 20000;
    const numberOfOps = (areaDimensions[0] / tileSize) * (areaDimensions[1] / tileSize);
    console.log('Rough op estimate: ', numberOfOps);
    if (numberOfOps > OVERLOAD_VALUE) {
      console.warn('Too many ops, aborting: ', numberOfOps);
      alert('Too many ops at this tile size - please increase size');
    }

    return numberOfOps > OVERLOAD_VALUE;
  }

  private assignCategoryToPerlinPoint(value: number) {
    const CATEGORY_A_VAL_MAX = MAX_PERLIN_VALUE * 0.5;
    const CATEGORY_B_VAL_MAX = MAX_PERLIN_VALUE * 0.75;
    // const CATEGORY_C_VAL_MAX = MAX_PERLIN_VALUE;

    if (value <=  CATEGORY_A_VAL_MAX) {
      return 'baseline';
    } else if (value >  CATEGORY_A_VAL_MAX && value <=  CATEGORY_B_VAL_MAX) {
      return 'foreground A';
    } else {
      return 'foreground B';
    }

  }

  private generateTilesFromArea(noise: any, areaDimensions: AreaDimensions, tileSize: number, noiseRes?: number) {
    noise.seed(Math.random());
    const noiseResolution = noiseRes || NOISE_RESOLUTION;
    const getPointFromTile = (tileCoord: number) =>
      (tileCoord * tileSize) + (tileSize / 2);

    const tiles: Tiles = [];
    _.times(areaDimensions[1] / tileSize, (tileY: number) => {
      tiles[tileY] = tiles[tileY] || [];
      _.times(areaDimensions[0] / tileSize, (tileX: number) => {

        const initialValue = noise.simplex2(tileX / noiseResolution, tileY / noiseResolution);
        const value = Math.abs(initialValue) * MAX_PERLIN_VALUE;
        const category = this.assignCategoryToPerlinPoint(value);

        tiles[tileY][tileX] = {
          tileX,
          tileY,
          pointX: getPointFromTile(tileX),
          pointY: getPointFromTile(tileY),
          value,
          category,
        };
      });
    });

    return tiles;
  }

  private testPoints(tiles: Tiles, graphics: Phaser.GameObjects.Graphics) {
    const UNDERLAYER_COLOR = COLOR_WATER;
    const BASELINE_COLOR = COLOR_GRASS;
    const FOREGOUND_COLOR = COLOR_GROUND;
    const TOP_LAYER_COLOR = COLOR_ROCK;

    const categoryToColorMap = {
      'baseline': BASELINE_COLOR,
      'foreground A': FOREGOUND_COLOR,
      'foreground B': TOP_LAYER_COLOR,
    };


    for (let tilesX of tiles) {
      for (let tile of tilesX) {
        // let color: number = 0;
        // const polygon = this.generateTilePolygon(tile);
        // color = categoryToColorMap[tile.category];

        // this.generateFilledShape(polygon, graphics, color);
      }
    }

    const groupedTilesFlat = _.groupBy(_.flatMap(tiles), 'category');
    const categoryLayers = ['baseline', 'foreground A', 'foreground B'];

    for(let layer of categoryLayers) {
      const layerTiles = groupedTilesFlat[layer];

      for (let tile of layerTiles) {
        const polygon = this.generateTilePolygon(tile);
        let color = categoryToColorMap[tile.category];

        this.generateFilledShape(polygon, graphics, color);
      }
    }
  }

  private getRotated (outerP: any, centerP: any, angle: any) {
    const rad = angle * Math.PI/ 180;
    const rotatedX = Math.cos(rad) * (outerP.x - centerP.x) - Math.sin(rad) * (outerP.y-centerP.y) + centerP.x;
    const rotatedY = Math.sin(rad) * (outerP.x - centerP.x) + Math.cos(rad) * (outerP.y - centerP.y) + centerP.y;

    return [rotatedX, rotatedY];
  }

  private generateTilePolygon(tile: any): Phaser.Geom.Polygon  {
    const points: { x: any; y: any; }[] = [];
    const topPoint = {x: tile.pointX, y: tile.pointY + TILE_POLYGON_SIZE };
    const centerPoint = {x: tile.pointX, y: tile.pointY };
    const POLYGON_POINTS_NUM = TILE_POLYGON_POINTS;
    const TOTAL_ROT = 360;
    let lastRotation = 0;

    while (lastRotation < TOTAL_ROT) {
      let pointRotation = _.random(
        lastRotation + Math.floor(TOTAL_ROT / POLYGON_POINTS_NUM * 1.2),
        lastRotation + Math.floor(TOTAL_ROT / POLYGON_POINTS_NUM / 1.2)
      );

      if (pointRotation < TOTAL_ROT)points.push(...this.getRotated(topPoint, centerPoint, pointRotation));
      lastRotation = pointRotation;
    }

    return new Phaser.Geom.Polygon(points);
  }

  private generateFilledShape(shapePolygon: Phaser.Geom.Polygon, graphics: Phaser.GameObjects.Graphics, color: any) {

    // graphics.lineStyle(2, color);
    graphics.beginPath();
    graphics.moveTo(shapePolygon.points[0].x, shapePolygon.points[0].y);

    for (let i = 1; i < shapePolygon.points.length; i++)
    {
        graphics.lineTo(shapePolygon.points[i].x, shapePolygon.points[i].y);
    }
    graphics.fillStyle(color, 1);
    graphics.fillPath();
    graphics.closePath();
    graphics.strokePath();
  }

}
