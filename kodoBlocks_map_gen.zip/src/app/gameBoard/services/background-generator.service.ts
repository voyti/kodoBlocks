import { Injectable } from '@angular/core';
import noise from 'noisejs';
type AreaDimensions = (number | undefined)[];

const MAX_PERLIN_VALUE = 256;

const COLOR_GRASS = 0x91c483;
const COLOR_GROUND = 0xCFB784;
const COLOR_FOREST = 0x125C13;
const COLOR_WATER = 0x38A3A5;
const COLOR_ROCK = 0x99A799;

@Injectable({
  providedIn: 'root'
})
export class BackgroundGeneratorService {
  noise: any;

  constructor() {
    this.noise = new (noise as any).Noise(Math.random());
  }

  generate(areaDimensions: AreaDimensions, graphics: Phaser.GameObjects.Graphics, scene: Phaser.Scene) {
    const shape = new Phaser.Geom.Polygon([
      0, 143,
      0, 92,
      110, 40,
      244, 4,
      330, 0,
      458, 12,
      574, 18,
      600, 79,
      594, 153,
      332, 152,
      107, 157
    ]);

    if (areaDimensions?.[0] && areaDimensions?.[1]) {
      // this.generateFilledShape(shape, graphics);
      let points = this.getAreaShapes(this.noise, areaDimensions[0], areaDimensions[1])
      console.log(points);
      this.testPoints(points, graphics);
    }
  }

  private getAreaShapes(noise: any, width: number, height: number) {
    let resultPoints: number[][] = [[]];
    noise.seed(Math.random());

    for (var x = 0; x < width; x++) {
      for (var y = 0; y < height; y++) {
        // noise.simplex2 and noise.perlin2 for 2d noise
        var value = noise.simplex2(x / 100, y / 100);
        resultPoints[x] = resultPoints[x] || [];
        resultPoints[x][y] = Math.abs(value) * MAX_PERLIN_VALUE;
      }
    }

    return resultPoints;
  }

  private testPoints(points: number[][], graphics: Phaser.GameObjects.Graphics) {
    const UNDERLAYER_COLOR = COLOR_WATER;
    const BASELINE_COLOR = COLOR_GRASS;
    const FOREGOUND_COLOR = COLOR_GROUND;
    const TOP_LAYER_COLOR = COLOR_ROCK;

    const CATEGORY_0_VAL_MAX = MAX_PERLIN_VALUE * 0.1;
    const CATEGORY_A_VAL_MAX = MAX_PERLIN_VALUE * 0.5;
    const CATEGORY_B_VAL_MAX = MAX_PERLIN_VALUE * 0.75;
    const CATEGORY_C_VAL_MAX = MAX_PERLIN_VALUE;

    for (let [pointY, pointsX] of points.entries()) {
      for (let [pointX, value] of pointsX.entries()) {

        if (value <=  CATEGORY_0_VAL_MAX) {
          graphics.fillStyle(UNDERLAYER_COLOR, 1);
        } else if (value >  CATEGORY_0_VAL_MAX && value <=  CATEGORY_A_VAL_MAX) {
          graphics.fillStyle(BASELINE_COLOR, 1);
        } else if (value >  CATEGORY_A_VAL_MAX && value <= CATEGORY_B_VAL_MAX) {
          graphics.fillStyle(FOREGOUND_COLOR, 1);
        } else {
            graphics.fillStyle(TOP_LAYER_COLOR, 1);
        }

        graphics.fillPoint(pointX, pointY, value / (MAX_PERLIN_VALUE / 2));
      }
    }
  }

  private generateFilledShape(shapePolygon: Phaser.Geom.Polygon, graphics: Phaser.GameObjects.Graphics) {
    graphics.lineStyle(2, 0x00aa00);
    graphics.beginPath();
    graphics.moveTo(shapePolygon.points[0].x, shapePolygon.points[0].y);

    for (var i = 1; i < shapePolygon.points.length; i++)
    {
        graphics.lineTo(shapePolygon.points[i].x, shapePolygon.points[i].y);
    }
    graphics.fillStyle(0xffff00, 1);
    graphics.fillPath();
    graphics.closePath();
    graphics.strokePath();
  }

}
