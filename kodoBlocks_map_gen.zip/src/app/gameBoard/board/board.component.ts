import { Component, OnInit } from '@angular/core';
import * as Phaser from 'phaser';
import { BackgroundGeneratorService } from '../services/background-generator.service';
type AreaDimensions = (number | undefined)[];

@Component({
  selector: 'app-board',
  templateUrl: './board.component.html',
  styleUrls: ['./board.component.scss']
})
export class BoardComponent implements OnInit {
  config: Phaser.Types.Core.GameConfig;
  logger: Console;

  constructor(private backgroundGeneratorService: BackgroundGeneratorService) {
    this.config = {
      width: 800,
      height: 600,
      type: Phaser.WEBGL,
      parent: 'board',
      scene: {
        // preload: preload,
          create: this.getPhaserCreate(),
      }
    };

    this.logger = console;
  }

  ngOnInit(): void {
    this.initializePhaser();
  }

  initializePhaser() {
    var game = new Phaser.Game(this.config);
  }


  getPhaserCreate(): Phaser.Types.Scenes.SceneCreateCallback {
    const self = this;

    const phaseCreateFunction = (phaserScene: Phaser.Scene) => {
      var graphics = phaserScene.add.graphics();

      if (typeof this.config.height === 'number' && typeof this.config.width === 'number') {
        const areaDimensions: AreaDimensions = [this.config.height, this.config.width];
        this.backgroundGeneratorService.generate(areaDimensions, graphics, phaserScene);
      } else {
        this.logger.warn('Parameter for config.height/config.width are not numbers, can\'t proceed with bg generation');
      }
    };

    return function create (this) {
      phaseCreateFunction(this);

      // graphics.fillStyle(0xffff00, 1);
      // graphics.fillRect(100, 100, 256, 256);

      // graphics.fillStyle(0xff00ff, 0.5);
      // graphics.fillRect(300, 200, 256, 256);

      // graphics.fillStyle(0x00ff00, 1);
      // graphics.fillTriangle(200, 200, 400, 50, 500, 300);
    }
  }

}
